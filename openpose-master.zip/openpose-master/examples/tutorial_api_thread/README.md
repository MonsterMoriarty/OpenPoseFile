# Thread API Examples
**NOTE**: This is an advanced API, you are most probably looking for the [examples/tutorial_api_python/](../tutorial_api_python/) examples folder, which provides examples of the thread API but applied to body pose estimation.

This folder provides examples to the basic OpenPose thread mechanism API. It is only meant for people interesed in the multi-thread architecture without been interesed in the OpenPose pose estimation algorithm.
